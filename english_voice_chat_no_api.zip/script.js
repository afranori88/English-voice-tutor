const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US';

const chatBox = document.getElementById('chat-box');
const startButton = document.getElementById('start-button');

startButton.onclick = () => {
  recognition.start();
};

recognition.onresult = (event) => {
  const text = event.results[0][0].transcript;
  appendMessage('You', text);

  // Simple echo response
  const botResponse = `Great! You said: "${text}". Let's practice more!`;
  appendMessage('Bot', botResponse);
  speak(botResponse);
};

function appendMessage(sender, message) {
  const msg = document.createElement('p');
  msg.innerHTML = `<strong>${sender}:</strong> ${message}`;
  chatBox.appendChild(msg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function speak(text) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'en-US';
  speechSynthesis.speak(utterance);
}
