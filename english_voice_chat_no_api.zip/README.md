# English Speaking Practice (No API)

This is a simple browser-based voice chat app to practice English speaking.

## Features

- Uses browser SpeechRecognition to convert your voice to text.
- Displays the conversation in a chat window.
- Replies using text-to-speech (SpeechSynthesis).
- No API key or internet server required.

## How to Use

1. Open `index.html` in a modern browser (Chrome recommended).
2. Click "Start Talking".
3. Speak in English. The browser will transcribe and respond.
4. Practice as many times as you like!

**Note**: You must allow microphone access when prompted.

Enjoy speaking English!
